-- =============================================
-- TechNova Assignment - Complete SQL Script
-- =============================================

-- USER STORY 1: DATABASE SETUP (DDL)
CREATE DATABASE IF NOT EXISTS TechNovaDB;
USE TechNovaDB;

CREATE TABLE Department (
    DeptID INT PRIMARY KEY,
    DeptName VARCHAR(50) NOT NULL UNIQUE,
    Location VARCHAR(50) NOT NULL
);

CREATE TABLE Employee (
    EmpID INT PRIMARY KEY,
    EmpName VARCHAR(100) NOT NULL,
    Gender CHAR(1) CHECK (Gender IN ('M', 'F')),
    DOB DATE NOT NULL,
    HireDate DATE NOT NULL,
    DeptID INT,
    FOREIGN KEY (DeptID) REFERENCES Department(DeptID)
);

CREATE TABLE Project (
    ProjectID INT PRIMARY KEY,
    ProjectName VARCHAR(100) NOT NULL,
    DeptID INT,
    StartDate DATE,
    EndDate DATE,
    FOREIGN KEY (DeptID) REFERENCES Department(DeptID)
);

CREATE TABLE Performance (
    EmpID INT,
    ProjectID INT,
    Rating DECIMAL(3,1) CHECK (Rating BETWEEN 1.0 AND 5.0),
    ReviewDate DATE,
    PRIMARY KEY (EmpID, ProjectID),
    FOREIGN KEY (EmpID) REFERENCES Employee(EmpID),
    FOREIGN KEY (ProjectID) REFERENCES Project(ProjectID)
);

CREATE TABLE Reward (
    EmpID INT,
    RewardMonth DATE,
    RewardAmount DECIMAL(10,2),
    PRIMARY KEY (EmpID, RewardMonth),
    FOREIGN KEY (EmpID) REFERENCES Employee(EmpID)
);

CREATE INDEX idx_EmpName ON Employee(EmpName);
CREATE INDEX idx_DeptID ON Employee(DeptID);

-- =============================================
-- USER STORY 2: INSERT AND MANAGE DATA (DML)
-- =============================================

INSERT INTO Department VALUES
(101, 'IT', 'Bangalore'),
(102, 'HR', 'Delhi'),
(103, 'Finance', 'Mumbai'),
(104, 'Marketing', 'Hyderabad'),
(105, 'Operations', 'Chennai');

INSERT INTO Employee VALUES
(1, 'Asha', 'F', '1990-07-12', '2018-06-10', 101),
(2, 'Raj', 'M', '1988-04-09', '2020-03-22', 102),
(3, 'Neha', 'F', '1995-01-15', '2021-08-05', 101),
(4, 'Kiran', 'M', '1992-11-20', '2019-05-14', 103),
(5, 'Priya', 'F', '1993-03-08', '2022-01-10', 104);

INSERT INTO Project VALUES
(201, 'HR Portal', 102, '2023-01-01', '2023-06-30'),
(202, 'Finance Automation', 103, '2023-03-01', '2023-09-30'),
(203, 'IT Infrastructure', 101, '2022-07-01', '2023-01-31'),
(204, 'Marketing Campaign', 104, '2023-05-01', '2023-10-31'),
(205, 'Ops Dashboard', 105, '2023-02-01', '2023-08-31');

INSERT INTO Performance VALUES
(1, 203, 4.5, '2023-01-31'),
(2, 201, 3.8, '2023-06-30'),
(3, 203, 4.2, '2023-01-31'),
(4, 202, 4.7, '2023-09-30'),
(5, 204, 3.5, '2023-10-31');

INSERT INTO Reward VALUES
(1, '2023-01-01', 3000),
(2, '2023-02-01', 800),
(3, '2023-03-01', 2500),
(4, '2023-04-01', 4000),
(5, '2023-05-01', 1500);

-- Update one employee's department
UPDATE Employee SET DeptID = 105 WHERE EmpID = 2;

-- Delete reward where amount < 1000
DELETE FROM Reward WHERE RewardAmount < 1000;

-- =============================================
-- USER STORY 3: GENERATE INSIGHTS (DQL)
-- =============================================

-- 1. Employees who joined after 2019-01-01
SELECT * FROM Employee
WHERE HireDate > '2019-01-01';

-- 2. Average performance rating per department
SELECT d.DeptName, AVG(p.Rating) AS AvgRating
FROM Performance p
JOIN Employee e ON p.EmpID = e.EmpID
JOIN Department d ON e.DeptID = d.DeptID
GROUP BY d.DeptName;

-- 3. Employees with their age
SELECT EmpName, DOB,
TIMESTAMPDIFF(YEAR, DOB, CURDATE()) AS Age
FROM Employee;

-- 4. Total rewards given in current year
SELECT SUM(RewardAmount) AS TotalRewards
FROM Reward
WHERE YEAR(RewardMonth) = YEAR(CURDATE());

-- 5. Employees who received rewards greater than 2000
SELECT e.EmpName, r.RewardAmount
FROM Reward r
JOIN Employee e ON r.EmpID = e.EmpID
WHERE r.RewardAmount > 2000;

-- =============================================
-- USER STORY 4: JOINS AND SUBQUERIES
-- =============================================

-- 1. Employee Name, Department, Project, Rating
SELECT e.EmpName, d.DeptName, pr.ProjectName, p.Rating
FROM Performance p
JOIN Employee e ON p.EmpID = e.EmpID
JOIN Department d ON e.DeptID = d.DeptID
JOIN Project pr ON p.ProjectID = pr.ProjectID;

-- 2. Highest rated employee in each department
SELECT e.EmpName, d.DeptName, p.Rating
FROM Performance p
JOIN Employee e ON p.EmpID = e.EmpID
JOIN Department d ON e.DeptID = d.DeptID
WHERE p.Rating = (
    SELECT MAX(p2.Rating)
    FROM Performance p2
    JOIN Employee e2 ON p2.EmpID = e2.EmpID
    WHERE e2.DeptID = e.DeptID
);

-- 3. Employees with no rewards
SELECT EmpName
FROM Employee
WHERE EmpID NOT IN (
    SELECT DISTINCT EmpID FROM Reward
);

-- =============================================
-- USER STORY 5: TRANSACTIONS AND OPTIMIZATION
-- =============================================

-- EXPLAIN before index
EXPLAIN SELECT e.EmpName, d.DeptName, p.Rating
FROM Performance p
JOIN Employee e ON p.EmpID = e.EmpID
JOIN Department d ON e.DeptID = d.DeptID
JOIN Project pr ON p.ProjectID = pr.ProjectID;

-- Transaction
START TRANSACTION;
INSERT INTO Employee VALUES (6, 'Arjun', 'M', '1994-06-21', '2023-11-01', 105);
INSERT INTO Performance VALUES (6, 205, 4.0, '2024-01-15');
COMMIT;

-- Verify transaction
SELECT * FROM Employee WHERE EmpID = 6;
SELECT * FROM Performance WHERE EmpID = 6;

-- EXPLAIN after index
EXPLAIN SELECT e.EmpName, d.DeptName, p.Rating
FROM Performance p
JOIN Employee e ON p.EmpID = e.EmpID
JOIN Department d ON e.DeptID = d.DeptID
JOIN Project pr ON p.ProjectID = pr.ProjectID;