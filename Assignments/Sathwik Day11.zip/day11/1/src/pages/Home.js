import React, { useState } from "react";
import AddBookForm from "../components/AddBookForm";
import { getBooks } from "../store/BookStore";

function Home() {
  const [books, setBooks] = useState(getBooks());

  const refreshBooks = () => {
    setBooks([...getBooks()]);
  };

  return (
    <div style={{ padding: "20px" }}>
      <h1>BookVerse</h1>

      <AddBookForm onBookAdded={refreshBooks} />

      <h2>Book List</h2>

      {books.length === 0 ? (
        <p>No books added yet.</p>
      ) : (
        books.map((book) => (
          <div
            key={book.id}
            style={{
              border: "1px solid #ccc",
              padding: "10px",
              margin: "10px 0",
            }}
          >
            <h3>{book.title}</h3>
            <p>Author: {book.author}</p>
            <p>Price: ₹{book.price}</p>
          </div>
        ))
      )}
    </div>
  );
}

export default Home;