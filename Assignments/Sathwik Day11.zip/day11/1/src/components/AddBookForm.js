import React from "react";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import { addBookAction } from "../actions/bookActions";

const validationSchema = Yup.object({
  title: Yup.string().required("Title is required"),
  author: Yup.string().required("Author is required"),
  price: Yup.number().required("Price is required"),
});

function AddBookForm({ onBookAdded }) {
  return (
    <div style={{ marginBottom: "20px" }}>
      <h2>Add New Book</h2>

      <Formik
        initialValues={{
          title: "",
          author: "",
          price: "",
        }}
        validationSchema={validationSchema}
        onSubmit={(values, { resetForm }) => {
          const newBook = {
            id: Date.now(),
            ...values,
          };

          addBookAction(newBook);
          onBookAdded();

          resetForm();
        }}
      >
        <Form>

          <div>
            <label>Title</label>
            <Field name="title" />
            <ErrorMessage name="title" component="div" style={{ color: "red" }} />
          </div>

          <div>
            <label>Author</label>
            <Field name="author" />
            <ErrorMessage name="author" component="div" style={{ color: "red" }} />
          </div>

          <div>
            <label>Price</label>
            <Field name="price" type="number" />
            <ErrorMessage name="price" component="div" style={{ color: "red" }} />
          </div>

          <button type="submit">Add Book</button>

        </Form>
      </Formik>
    </div>
  );
}

export default AddBookForm;