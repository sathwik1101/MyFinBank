import { dispatch } from "../dispatcher/dispatcher";

export const addBookAction = (book) => {
  dispatch({
    type: "ADD_BOOK",
    payload: book,
  });
};