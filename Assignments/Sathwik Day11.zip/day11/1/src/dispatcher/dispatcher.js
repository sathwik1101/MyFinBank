import { addBook } from "../store/BookStore";

export const dispatch = (action) => {
  switch (action.type) {
    case "ADD_BOOK":
      addBook(action.payload);
      break;
    default:
      break;
  }
};