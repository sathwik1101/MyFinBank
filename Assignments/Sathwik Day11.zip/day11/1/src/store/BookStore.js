let books = [];

export const getBooks = () => books;

export const addBook = (book) => {
  books.push(book);
};