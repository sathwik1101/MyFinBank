import React, { useState } from "react";
import BookCard from "./BookCard";

const BookList = () => {
  const [viewMode, setViewMode] = useState("grid");
  const [searchTerm, setSearchTerm] = useState("");

  const books = [
    { id: 1, title: "Atomic Habits", author: "James Clear", price: 499 },
    { id: 2, title: "The Alchemist", author: "Paulo Coelho", price: 399 },
    { id: 3, title: "Rich Dad Poor Dad", author: "Robert Kiyosaki", price: 450 },
    { id: 4, title: "Deep Work", author: "Cal Newport", price: 550 }
  ];

  const filteredBooks = books.filter(book =>
    book.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div style={{ padding: "20px" }}>
      <h1>Featured Books</h1>

      {/* Controlled Search Input */}
      <input
        type="text"
        placeholder="Search books..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        style={{ padding: "8px", marginRight: "10px" }}
      />

      {/* Toggle Buttons */}
      <button onClick={() => setViewMode("grid")}>Grid View</button>
      <button onClick={() => setViewMode("list")} style={{ marginLeft: "10px" }}>
        List View
      </button>

      <div style={{ marginTop: "20px" }}>
        {filteredBooks.map(book => (
          <BookCard
            key={book.id}
            title={book.title}
            author={book.author}
            price={book.price}
            viewMode={viewMode}
          />
        ))}
      </div>
    </div>
  );
};

export default BookList;