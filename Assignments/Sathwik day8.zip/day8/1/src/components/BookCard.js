import React from "react";

const BookCard = ({ title, author, price, viewMode }) => {
  return (
    <div
      style={{
        border: "1px solid #ccc",
        padding: "15px",
        margin: "10px",
        borderRadius: "8px",
        width: viewMode === "grid" ? "200px" : "100%",
        display: viewMode === "grid" ? "inline-block" : "block"
      }}
    >
      <h3>{title}</h3>
      <p><strong>Author:</strong> {author}</p>
      <p><strong>Price:</strong> ₹{price}</p>
    </div>
  );
};

export default BookCard;