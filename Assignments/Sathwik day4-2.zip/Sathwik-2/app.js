const App = (function () {

    const postsContainer = document.getElementById("posts");
    const todosContainer = document.getElementById("todos");

    const POSTS_URL = "https://jsonplaceholder.typicode.com/posts";
    const TODOS_URL = "https://jsonplaceholder.typicode.com/todos";

    function showError(container, message) {
        container.innerHTML = `<p class="error">${message}</p>`;
    }
    async function loadPosts() {
        postsContainer.innerHTML = "Loading posts...";

        try {
            const response = await fetch(POSTS_URL);

            if (!response.ok) {
                throw new Error("Failed to fetch posts.");
            }

            const data = await response.json();
            displayPosts(data.slice(0, 5));

        } catch (error) {
            showError(postsContainer, error.message);
        }
    }

    function displayPosts(posts) {
        postsContainer.innerHTML = "";

        posts.forEach(post => {
            const div = document.createElement("div");
            div.className = "card";
            div.innerHTML = `
                <h3>${post.title}</h3>
                <p>${post.body}</p>
            `;
            postsContainer.appendChild(div);
        });
    }
    async function loadTodos() {
        todosContainer.innerHTML = "Loading todos...";

        try {
            const response = await fetch(TODOS_URL);

            if (!response.ok) {
                throw new Error("Failed to fetch todos.");
            }

            const data = await response.json();
            displayTodos(data.slice(0, 5));

        } catch (error) {
            showError(todosContainer, error.message);
        }
    }

    function displayTodos(todos) {
        todosContainer.innerHTML = "";

        todos.forEach(todo => {
            const div = document.createElement("div");
            div.className = "card";
            div.innerHTML = `
                <p>
                    <strong>${todo.title}</strong><br>
                    Status: ${todo.completed ? "Completed ✅" : "Pending ❌"}
                </p>
            `;
            todosContainer.appendChild(div);
        });
    }
    return {
        loadPosts,
        loadTodos
    };

})();