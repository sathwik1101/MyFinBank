// Load users from storage
let users = JSON.parse(localStorage.getItem("users")) || [];

// Activities array
let activities = [
    { id:1, activity:"Create tables from 12–19", subject:"Maths"},
    { id:2, activity:"Water cycle diagram", subject:"Science"},
    { id:3, activity:"Essay writing", subject:"English"},
    { id:4, activity:"Algebra worksheet", subject:"Maths"}
];

// REGISTER
function register(){
    let u = username.value.trim();
    let p = password.value.trim();

    if(!u || !p){
        message.innerText="Enter username & password";
        return;
    }

    users.push({username:u,password:p});
    localStorage.setItem("users",JSON.stringify(users));

    message.innerText="Registered Successfully";
}

// LOGIN
function login(){
    let u=username.value;
    let p=password.value;

    let valid=users.find(x=>x.username===u && x.password===p);

    if(valid){
        localStorage.setItem("currentUser",u);
        location.href="welcome.html";
    }
    else message.innerText="Invalid Login";
}

// WELCOME PAGE BUTTON
function goToActivity(){
    location.href="activity.html";
}

// FILTER ACTIVITIES
function filterActivities(){
    let s=subject.value;
    activityList.innerHTML="";

    activities
    .filter(a=>a.subject===s)
    .forEach(a=>{
        activityList.innerHTML+=`<p>${a.activity}</p>`;
    });
}
