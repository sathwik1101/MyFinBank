const express = require("express");
const coursesRouter = require("./routes/courses");

const app = express();

app.get("/", (req, res) => {
  res.send("Welcome to SkillSphere LMS API");
});

app.use("/courses", coursesRouter);

app.listen(4000, () => {
  console.log("Server running at http://localhost:4000");
});
