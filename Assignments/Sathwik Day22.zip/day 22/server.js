const express = require("express");
const mongoose = require("mongoose");
const bcrypt = require("bcrypt");
const session = require("express-session");
const passport = require("passport");
const LocalStrategy = require("passport-local").Strategy;
const path = require("path");
const User = require("./models/User");

const app = express();

mongoose.connect("mongodb://localhost:27017/SkillSphereDB")
  .then(() => console.log("MongoDB connected"))
  .catch((err) => console.log("DB Error:", err));

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(session({
  secret: "skillsphere_secret",
  resave: false,
  saveUninitialized: false
}));

app.use(passport.initialize());
app.use(passport.session());

passport.use(new LocalStrategy({ usernameField: "email" }, async (email, password, done) => {
  try {
    const user = await User.findOne({ email });
    if (!user) return done(null, false, { message: "User not found" });
    const match = await bcrypt.compare(password, user.password);
    if (!match) return done(null, false, { message: "Wrong password" });
    return done(null, user);
  } catch (err) {
    return done(err);
  }
}));

passport.serializeUser((user, done) => done(null, user.id));
passport.deserializeUser(async (id, done) => {
  try {
    const user = await User.findById(id);
    done(null, user);
  } catch (err) {
    done(err);
  }
});

const isAdmin = (req, res, next) => {
  if (req.isAuthenticated() && req.user.role === "admin") return next();
  res.status(403).send("Access Denied");
};

app.get("/", (req, res) => res.send("Welcome to SkillSphere LMS API"));

app.get("/register", (req, res) => res.render("register"));

app.post("/register", async (req, res) => {
  const { name, email, password } = req.body;
  const hashedPassword = await bcrypt.hash(password, 10);
  const user = new User({ name, email, password: hashedPassword });
  await user.save();
  console.log("User saved:", user);
  res.send(`Registration successful for ${name}`);
});

app.get("/login", (req, res) => res.render("login"));

app.post("/login", passport.authenticate("local", {
  failureRedirect: "/login"
}), (req, res) => {
  res.redirect("/admin");
});

app.get("/admin", isAdmin, (req, res) => {
  res.send(`Welcome, Admin! Logged in as ${req.user.name}`);
});

app.get("/logout", (req, res) => {
  req.logout(() => res.redirect("/login"));
});

app.listen(4000, () => console.log("Server running at http://localhost:4000"));
