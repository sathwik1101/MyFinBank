import React from "react";
import BookList from "./components/BookList";

function App() {
  return (
    <div className="container mt-4">
      <h1 className="text-center mb-4">BookVerse</h1>
      <BookList />
    </div>
  );
}

export default App;