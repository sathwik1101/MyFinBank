import React, { useState, useRef } from "react";
import BookCard from "./BookCard";
import AuthorInfo from "./AuthorInfo";

const BookList = () => {
  const [selectedAuthor, setSelectedAuthor] = useState("");
  const searchRef = useRef();
  

  const books = [
    { id: 1, title: "Atomic Habits", author: "James Clear", price: 499 },
    { id: 2, title: "The Alchemist", author: "Paulo Coelho", price: 399 },
    { id: 3, title: "Rich Dad Poor Dad", author: "Robert Kiyosaki", price: 450 },
    { id: 4, title: "Deep Work", author: "Cal Newport", price: 550 }
  ];

  const handleSearch = () => {
    console.log("Search value:", searchRef.current.value);
  };

  return (
    <div>
      
      <div className="mb-3">
        <input
          type="text"
          ref={searchRef}
          className="form-control"
          placeholder="Type something..."
        />
        <button
          className="btn btn-secondary mt-2"
          onClick={handleSearch}
        >
          Log Input Value
        </button>
      </div>

      <div className="row">
        {books.map(book => (
          <BookCard
            key={book.id}
            title={book.title}
            author={book.author}
            price={book.price}
            onSelect={setSelectedAuthor}
          />
        ))}
      </div>

      <AuthorInfo author={selectedAuthor} />
    </div>
  );
};

export default BookList;