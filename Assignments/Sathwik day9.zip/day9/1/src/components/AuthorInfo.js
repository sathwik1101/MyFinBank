import React, { Component } from "react";

class AuthorInfo extends Component {
  componentDidMount() {
    console.log("AuthorInfo component mounted");
  }

  render() {
    const { author } = this.props;

    if (!author) {
      return (
        <div className="alert alert-info mt-3">
          Select a book to view author details.
        </div>
      );
    }

    return (
      <div className="card mt-3">
        <div className="card-body">
          <h5 className="card-title">Author Details</h5>
          <p className="card-text">
            You selected books written by <strong>{author}</strong>.
          </p>
        </div>
      </div>
    );
  }
}

export default AuthorInfo;