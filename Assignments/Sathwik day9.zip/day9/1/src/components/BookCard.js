import React from "react";
import PropTypes from "prop-types";

const BookCard = ({ title, author, price, onSelect }) => {
  return (
    <div className="col-md-4 mb-4">
      <div className="card h-100 shadow-sm">
        <div className="card-body">
          <h5 className="card-title">{title}</h5>
          <p className="card-text">
            <strong>Author:</strong> {author}
          </p>
          <p className="card-text">
            <strong>Price:</strong> ₹{price}
          </p>
          <button
            className="btn btn-primary"
            onClick={() => onSelect(author)}
          >
            View Author Info
          </button>
        </div>
      </div>
    </div>
  );
};

BookCard.propTypes = {
  title: PropTypes.string.isRequired,
  author: PropTypes.string.isRequired,
  price: PropTypes.number.isRequired,
  onSelect: PropTypes.func.isRequired,
};

export default BookCard;