db.authors.insertMany([
  { name: "J.K. Rowling", nationality: "British", birthYear: 1965 },
  { name: "George R.R. Martin", nationality: "American", birthYear: 1948 },
  { name: "Isaac Asimov", nationality: "American", birthYear: 1920 },
  { name: "J.R.R. Tolkien", nationality: "British", birthYear: 1892 }
]);

db.users.insertMany([
  { name: "Ravi Kumar", email: "ravi@gmail.com", joinDate: new Date("2024-09-15") },
  { name: "Sneha Reddy", email: "sneha@gmail.com", joinDate: new Date("2024-11-20") },
  { name: "Arjun Mehta", email: "arjun@gmail.com", joinDate: new Date("2025-01-10") },
  { name: "Priya Sharma", email: "priya@gmail.com", joinDate: new Date("2025-02-05") }
]);

db.books.insertMany([
  {
    title: "Harry Potter and the Philosopher's Stone",
    genre: "Fantasy",
    publicationYear: 1997,
    authorId: "J.K. Rowling",
    ratings: [
      { user: "Ravi Kumar", score: 5, comment: "Magical and timeless!" },
      { user: "Sneha Reddy", score: 4, comment: "Loved it." }
    ]
  },
  {
    title: "A Game of Thrones",
    genre: "Fantasy",
    publicationYear: 1996,
    authorId: "George R.R. Martin",
    ratings: [
      { user: "Arjun Mehta", score: 5, comment: "Epic fantasy!" },
      { user: "Priya Sharma", score: 4, comment: "Complex and gripping." }
    ]
  },
  {
    title: "Foundation",
    genre: "Science Fiction",
    publicationYear: 1951,
    authorId: "Isaac Asimov",
    ratings: [
      { user: "Ravi Kumar", score: 5, comment: "A masterpiece of sci-fi." }
    ]
  },
  {
    title: "The Lord of the Rings",
    genre: "Fantasy",
    publicationYear: 1954,
    authorId: "J.R.R. Tolkien",
    ratings: [
      { user: "Sneha Reddy", score: 5, comment: "The greatest fantasy ever written." },
      { user: "Arjun Mehta", score: 5, comment: "Unmatched world-building." }
    ]
  },
  {
    title: "I, Robot",
    genre: "Science Fiction",
    publicationYear: 2004,
    authorId: "Isaac Asimov",
    ratings: [
      { user: "Priya Sharma", score: 4, comment: "Thought-provoking short stories." }
    ]
  }
]);

db.books.find({ genre: "Science Fiction" });

db.books.updateOne(
  { title: "I, Robot" },
  { $set: { publicationYear: 1950 } }
);

db.users.deleteOne({ name: "Priya Sharma" });

db.books.updateOne(
  { title: "Foundation" },
  { $push: { ratings: { user: "Sneha Reddy", score: 5, comment: "Brilliant writing!" } } }
);

db.books.find({ publicationYear: { $gt: 2015 } });

db.books.distinct("authorId", { genre: "Fantasy" });

db.users.find({ joinDate: { $gte: new Date(new Date().setMonth(new Date().getMonth() - 6)) } });

db.books.find({
  $expr: {
    $gt: [{ $avg: "$ratings.score" }, 4]
  }
});
