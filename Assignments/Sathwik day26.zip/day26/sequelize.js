const { Sequelize, DataTypes } = require("sequelize");

const sequelize = new Sequelize({
  dialect: "sqlite",
  storage: "skillsphere.db",
  logging: false
});

const Instructor = sequelize.define("Instructor", {
  name: { type: DataTypes.STRING, allowNull: false },
  email: { type: DataTypes.STRING, allowNull: false }
});

const Course = sequelize.define("Course", {
  name: { type: DataTypes.STRING, allowNull: false },
  duration: { type: DataTypes.STRING, allowNull: false }
});

Instructor.hasMany(Course, { foreignKey: "instructorId" });
Course.belongsTo(Instructor, { foreignKey: "instructorId" });

async function run() {
  await sequelize.sync({ force: true });
  console.log("Database synced");

  const instructor = await Instructor.create({ name: "Prof. Sharma", email: "sharma@skillsphere.com" });

  await Course.create({ name: "React Mastery", duration: "6 weeks", instructorId: instructor.id });
  await Course.create({ name: "Node.js Fundamentals", duration: "4 weeks", instructorId: instructor.id });
  await Course.create({ name: "MongoDB Essentials", duration: "3 weeks", instructorId: instructor.id });

  const result = await Instructor.findOne({
    where: { name: "Prof. Sharma" },
    include: Course
  });

  console.log(`\nCourses by ${result.name}:`);
  result.Courses.forEach(c => console.log(`- ${c.name} (${c.duration})`));

  await sequelize.close();
}

run();
