const { Sequelize, DataTypes } = require("sequelize");

const sequelize = new Sequelize({
  dialect: "sqlite",
  storage: "skillsphere_courses.db",
  logging: false
});

const Course = sequelize.define("Course", {
  name: { type: DataTypes.STRING, allowNull: false },
  duration: { type: DataTypes.STRING, allowNull: false }
});

async function run() {
  await sequelize.sync({ force: true });
  console.log("Database connected");

  await Course.create({ name: "React Mastery", duration: "6 weeks" });
  await Course.create({ name: "Node.js Fundamentals", duration: "4 weeks" });
  await Course.create({ name: "MongoDB Essentials", duration: "3 weeks" });

  console.log("INSERT INTO courses successful");

  const courses = await Course.findAll();
  courses.forEach(c => console.log(`- ${c.name} (${c.duration})`));

  await sequelize.close();
}

run();