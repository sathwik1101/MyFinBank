const mongoose = require("mongoose");

mongoose.connect("mongodb://localhost:27017/SkillSphereDB")
  .then(() => console.log("MongoDB connected"))
  .catch((err) => console.log("Error:", err));

const userSchema = new mongoose.Schema({
  name: String,
  email: String
});

const enrollmentSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  courseName: String,
  enrolledAt: { type: Date, default: Date.now }
});

const User = mongoose.model("User", userSchema);
const Enrollment = mongoose.model("Enrollment", enrollmentSchema);

async function run() {
  const user = await User.create({ name: "John Doe", email: "john@example.com" });
  console.log("User created:", user.name);

  await Enrollment.create({ userId: user._id, courseName: "React Mastery" });
  await Enrollment.create({ userId: user._id, courseName: "Node.js Fundamentals" });

  const enrollments = await Enrollment.find().populate("userId");
  console.log("Enrollment details:");
  enrollments.forEach(e => {
    console.log(`- ${e.userId.name} enrolled in ${e.courseName}`);
  });

  mongoose.connection.close();
}

run();
