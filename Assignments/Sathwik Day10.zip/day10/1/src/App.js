import React from "react";
import { Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import BookDetails from "./pages/BookDetails";

function App() {
  return (
    <div>
      <h1 style={{ textAlign: "center" }}>BookVerse</h1>

      <Routes>
        <Route path="/" element={<Home isLoading={false} />} />
        <Route path="/book/:id" element={<BookDetails />} />
      </Routes>
    </div>
  );
}

export default App;