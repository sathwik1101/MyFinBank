import React from "react";

const withLoading = (WrappedComponent) => {
  return function EnhancedComponent({ isLoading, ...props }) {
    if (isLoading) {
      return <p style={{ padding: "20px" }}>Loading...</p>;
    }

    return <WrappedComponent {...props} />;
  };
};

export default withLoading;