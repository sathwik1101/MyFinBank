import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import withLoading from "../hoc/withLoading";
import MouseTracker from "../renderProps/MouseTracker";

function Home({ isLoading }) {
  const [books, setBooks] = useState([]);

  useEffect(() => {
    fetch("http://localhost:5000/books")
      .then((res) => res.json())
      .then((data) => setBooks(data))
      .catch((err) => console.error("Error fetching books:", err));
  }, []);

  if (isLoading) {
    return <p style={{ padding: "20px" }}>Loading...</p>;
  }

  return (
    <div style={{ padding: "20px" }}>
      <h2>Book List</h2>

      {books.map((book) => (
        <div
          key={book.id}
          style={{
            border: "1px solid #ccc",
            padding: "10px",
            margin: "10px 0",
          }}
        >
          <h3>{book.title}</h3>
          <p>Author: {book.author}</p>
          <p>Price: ₹{book.price}</p>

          <Link to={`/book/${book.id}`}>
            <button>View Details</button>
          </Link>
        </div>
      ))}
      <MouseTracker
        render={(position) => (
          <p style={{ marginTop: "20px" }}>
            Mouse Position: {position.x}, {position.y}
          </p>
        )}
      />
    </div>
  );
}

export default withLoading(Home);