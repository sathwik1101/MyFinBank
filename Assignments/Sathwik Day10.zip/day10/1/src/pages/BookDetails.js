import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";

function BookDetails() {
  const { id } = useParams();
  const [book, setBook] = useState(null);

  useEffect(() => {
    fetch(`http://localhost:5000/books/${id}`)
      .then((res) => res.json())
      .then((data) => setBook(data))
      .catch((err) => console.error("Error fetching book:", err));
  }, [id]);

  if (!book) {
    return <p style={{ padding: "20px" }}>Loading book details...</p>;
  }

  return (
    <div style={{ padding: "20px" }}>
      <h2>{book.title}</h2>
      <p><strong>Author:</strong> {book.author}</p>
      <p><strong>Price:</strong> ₹{book.price}</p>
      <p><strong>Description:</strong> {book.description}</p>

      <Link to="/">
        <button style={{ marginTop: "10px" }}>Back to Home</button>
      </Link>
    </div>
  );
}

export default BookDetails;