import React from "react";
import ReactDOM from "react-dom";

function ModalPortal({ children }) {

  const portalRoot = document.getElementById("portal-root");

  return ReactDOM.createPortal(
    <div style={{
      position: "fixed",
      top: "30%",
      left: "30%",
      background: "white",
      padding: "20px",
      border: "2px solid black"
    }}>
      {children}
    </div>,
    portalRoot
  );
}

export default ModalPortal;