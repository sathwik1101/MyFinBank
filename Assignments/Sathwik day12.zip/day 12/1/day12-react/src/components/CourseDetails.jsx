import React from "react";

function CourseDetails() {
  return (
    <div style={{border:"1px solid gray", padding:"10px", marginTop:"10px"}}>
      <h2>Course Details</h2>
      <p>This course teaches advanced React concepts like Lazy Loading, Error Boundaries and Portals.</p>
    </div>
  );
}

export default CourseDetails;