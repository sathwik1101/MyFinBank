import React from "react";

function InstructorProfile() {
  return (
    <div style={{border:"1px solid gray", padding:"10px", marginTop:"10px"}}>
      <h2>Instructor Profile</h2>
      <p>Name: John Doe</p>
      <p>Experience: 10 years in React Development</p>
    </div>
  );
}

export default InstructorProfile;