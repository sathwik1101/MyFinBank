import React from "react";

function BuggyComponent() {

  throw new Error("Crash!");

  return <h1>This will never render</h1>;
}

export default BuggyComponent;