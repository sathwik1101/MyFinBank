import React from "react";

function StatsCard({ title, value, lastUpdated }) {

  console.log(title + " rendered");

  return (
    <div style={{
      border: "1px solid black",
      padding: "10px",
      marginTop: "10px",
      width: "200px"
    }}>
      <h3>{title}</h3>
      <p>Value: {value}</p>
      <p>Last Updated: {lastUpdated}</p>
    </div>
  );
}

export default React.memo(StatsCard);