import React, { lazy, Suspense, useState } from "react";
import StatsCard from "./components/StatsCard";
import ErrorBoundary from "./components/ErrorBoundary";
import BuggyComponent from "./components/BuggyComponent";
import ModalPortal from "./components/ModalPortal";

const CourseDetails = lazy(() => import("./components/CourseDetails"));
const InstructorProfile = lazy(() => import("./components/InstructorProfile"));

function App() {
  const [showCourse, setShowCourse] = useState(false);
  const [showInstructor, setShowInstructor] = useState(false);
  const [users, setUsers] = useState(100);
  const [orders, setOrders] = useState(50);
  const [showModal, setShowModal] = useState(false);

  return (
    <div style={{ padding: "20px" }}>
      <h1>Day 12 – React Advanced Concepts</h1>

      <button onClick={() => setShowCourse(true)}>
        View Course Details
      </button>

      <button onClick={() => setShowInstructor(true)} style={{marginLeft:"10px"}}>
        View Instructor Profile
      </button>
      <h2>Dashboard Stats</h2>

      <button onClick={() => setUsers(users + 1)}>
        Simulate Update
      </button>
      <StatsCard
      title="Users"
      value={users}
      lastUpdated="Now"
    />

    <StatsCard
      title="Orders"  
      value={orders}
      lastUpdated="Now"
    />

      <Suspense fallback={<p>Loading component...</p>}>
        {showCourse && <CourseDetails />}
        {showInstructor && <InstructorProfile />}
      </Suspense>
      <h2>Error Boundary Example</h2>

    <ErrorBoundary>
      <BuggyComponent />
    </ErrorBoundary>
    <h2>React Portal Example</h2>

    <button onClick={() => setShowModal(true)}>
      Open Modal
    </button>
    {showModal && (
    <ModalPortal>
      <h3>This is rendered using React Portal</h3>
      <button onClick={() => setShowModal(false)}>
        Close
      </button>
    </ModalPortal>
  )}

    </div>
  );
}

export default App;