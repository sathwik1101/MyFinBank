const express = require("express");
const path = require("path");

const app = express();

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

app.use((req, res, next) => {
  console.log(`[${req.method}] ${req.url} at ${new Date().toISOString()}`);
  next();
});

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.get("/", (req, res) => {
  res.send("Welcome to SkillSphere LMS API");
});

app.post("/users", (req, res) => {
  res.json({ message: "User created successfully", data: req.body });
});

app.get("/courses", (req, res) => {
  const courses = [
    { id: 101, name: "React Mastery", duration: "6 weeks" },
    { id: 102, name: "Node.js Fundamentals", duration: "4 weeks" },
    { id: 103, name: "MongoDB Essentials", duration: "3 weeks" },
    { id: 104, name: "Python for Data Science", duration: "8 weeks" },
    { id: 105, name: "AWS Cloud Practitioner", duration: "5 weeks" }
  ];
  res.render("courses", { courses });
});

app.listen(4000, () => {
  console.log("Server running at http://localhost:4000");
});
