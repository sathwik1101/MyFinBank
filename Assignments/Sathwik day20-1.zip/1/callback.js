const fs = require("fs");

fs.writeFileSync("data.txt", "This is data from data.txt file.");

console.log("Starting file read...");

fs.readFile("data.txt", "utf8", (err, data) => {
  if (err) {
    console.log("Error reading file:", err);
    return;
  }
  setTimeout(() => {
    console.log(data);
    console.log("Read operation completed");
  }, 1000);
});

console.log("This runs before file is read (async behavior)");
