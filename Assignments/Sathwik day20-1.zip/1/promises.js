const fs = require("fs").promises;

fs.writeFile("input.txt", "Hello from input.txt! This content will be copied.")
  .then(() => fs.readFile("input.txt", "utf8"))
  .then((data) => fs.writeFile("output.txt", data))
  .then(() => {
    console.log("File copied successfully!");
  })
  .catch((err) => {
    console.log("Error:", err.message);
  });
