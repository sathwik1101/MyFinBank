const fs = require("fs").promises;

async function copyFile() {
  try {
    await fs.writeFile("input.txt", "Hello from input.txt! This content will be copied.");

    console.log("Reading input.txt...");
    const data = await fs.readFile("input.txt", "utf8");

    console.log("Simulating slow operation...");
    await new Promise((res) => setTimeout(res, 1000));

    await fs.writeFile("output.txt", data);
    console.log("File copied successfully!");
  } catch (err) {
    console.log("Error:", err.message);
  }
}

copyFile();
