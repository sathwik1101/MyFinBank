import { useContext } from "react";
import { ThemeProvider, ThemeContext } from "./context/ThemeContext";
import ThemeComponent from "./components/ThemeComponent";
import WorkoutTracker from "./components/WorkoutTracker";
import ReduxCounter from "./components/ReduxCounter";

function AppContent() {

  const { theme, toggleTheme } = useContext(ThemeContext);

  const style = {
    backgroundColor: theme === "light" ? "#ffffff" : "#222222",
    color: theme === "light" ? "#000000" : "#ffffff",
    minHeight: "100vh",
    padding: "20px"
  };

  return (
    <div style={style}>
      <h1>React Hooks & State Management</h1>

      <button onClick={toggleTheme}>
        Toggle Theme
      </button>

      <ThemeComponent />

      <WorkoutTracker />

      <ReduxCounter />

    </div>
  );
}

function App() {
  return (
    <ThemeProvider>
      <AppContent />
    </ThemeProvider>
  );
}

export default App;