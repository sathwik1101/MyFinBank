import { useSelector, useDispatch } from "react-redux";
import { increment, decrement } from "../redux/counterSlice";

function ReduxCounter() {

  const count = useSelector((state) => state.counter.value);
  const dispatch = useDispatch();

  return (
    <div style={{marginTop:"30px"}}>
      <h2>Redux Counter</h2>

      <p>Count: {count}</p>

      <button onClick={() => dispatch(increment())}>
        Increment
      </button>

      <button onClick={() => dispatch(decrement())} style={{marginLeft:"10px"}}>
        Decrement
      </button>
    </div>
  );
}

export default ReduxCounter;