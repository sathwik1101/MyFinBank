import { useContext } from "react";
import { ThemeContext } from "../context/ThemeContext";

function ThemeComponent() {

  const { theme } = useContext(ThemeContext);

  return (
    <div>
      <h2>Current Theme: {theme}</h2>
      <p>This component consumes theme using useContext()</p>
    </div>
  );
}

export default ThemeComponent;