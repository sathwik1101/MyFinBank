import { useState, useEffect, useRef } from "react";

function WorkoutTracker() {

  const [workouts, setWorkouts] = useState([]);
  const [input, setInput] = useState("");

  const inputRef = useRef(null);

  useEffect(() => {
    inputRef.current.focus();
  }, []);

  const addWorkout = () => {

    if (input.trim() === "") return;

    const newWorkout = {
      id: Date.now(),
      name: input
    };

    setWorkouts([...workouts, newWorkout]);
    setInput("");
  };

  return (
    <div style={{marginTop:"40px"}}>

      <h2>Workout Tracker</h2>

      <input
        ref={inputRef}
        type="text"
        placeholder="Enter workout"
        value={input}
        onChange={(e) => setInput(e.target.value)}
      />

      <button onClick={addWorkout} style={{marginLeft:"10px"}}>
        Add Workout
      </button>

      <ul>
        {workouts.map((workout) => (
          <li key={workout.id}>{workout.name}</li>
        ))}
      </ul>

    </div>
  );
}

export default WorkoutTracker;