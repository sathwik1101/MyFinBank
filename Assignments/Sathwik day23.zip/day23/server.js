const express = require("express");
const { body, validationResult } = require("express-validator");
const rateLimit = require("express-rate-limit");

const app = express();
app.use(express.json());

let courses = [
  { id: 1, name: "React Mastery", duration: "6 weeks" },
  { id: 2, name: "Node.js Fundamentals", duration: "4 weeks" },
  { id: 3, name: "MongoDB Essentials", duration: "3 weeks" }
];
let nextId = 4;

const limiter = rateLimit({
  windowMs: 1 * 60 * 1000,
  max: 5,
  message: { error: "Too many requests" }
});

app.use("/api/courses", limiter);

app.get("/api/courses", (req, res) => {
  res.json(courses);
});

app.get("/api/courses/:id", (req, res) => {
  const course = courses.find(c => c.id === parseInt(req.params.id));
  if (!course) return res.status(404).json({ error: "Course not found" });
  res.json(course);
});

app.post("/api/courses", [
  body("name").notEmpty().withMessage("Course name is required"),
  body("duration").notEmpty().withMessage("Duration is required")
], (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ error: errors.array()[0].msg });
  }
  const course = { id: nextId++, name: req.body.name, duration: req.body.duration };
  courses.push(course);
  res.status(201).json(course);
});

app.put("/api/courses/:id", [
  body("name").notEmpty().withMessage("Course name is required"),
  body("duration").notEmpty().withMessage("Duration is required")
], (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ error: errors.array()[0].msg });
  }
  const index = courses.findIndex(c => c.id === parseInt(req.params.id));
  if (index === -1) return res.status(404).json({ error: "Course not found" });
  courses[index] = { id: parseInt(req.params.id), name: req.body.name, duration: req.body.duration };
  res.json(courses[index]);
});

app.delete("/api/courses/:id", (req, res) => {
  const index = courses.findIndex(c => c.id === parseInt(req.params.id));
  if (index === -1) return res.status(404).json({ error: "Course not found" });
  courses.splice(index, 1);
  res.json({ message: "Course deleted successfully" });
});

app.listen(4000, () => console.log("Server running at http://localhost:4000"));
