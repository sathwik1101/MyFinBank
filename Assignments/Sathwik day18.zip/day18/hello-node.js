console.log("Node.js Version:", process.version);
console.log("File Name:", __filename);
console.log("Directory:", __dirname);

let count = 0;

const interval = setInterval(() => {
  count += 3;
  console.log("Welcome to Node.js! (" + count + "s elapsed)");
  if (count >= 10) {
    clearInterval(interval);
    console.log("Timer stopped after 10 seconds.");
  }
}, 3000);
