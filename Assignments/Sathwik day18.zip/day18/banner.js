const figlet = require("figlet");
const chalk = require("chalk");

figlet("Welcome to Node.js", (err, data) => {
  if (err) {
    console.log("Error:", err);
    return;
  }
  console.log(chalk.cyan(data));
  console.log(chalk.green("Powered by npm packages: chalk + figlet"));
});
