const http = require("http");

const server = http.createServer((req, res) => {
  res.writeHead(200, { "Content-Type": "text/html" });

  if (req.url === "/") {
    res.end("<h1>Hello from Node.js Server</h1>");
  } else if (req.url === "/about") {
    res.end("<h1>About Page</h1><p>This is a simple Node.js HTTP server.</p>");
  } else {
    res.writeHead(404);
    res.end("<h1>404 - Page Not Found</h1>");
  }
});

server.listen(3000, () => {
  console.log("Server running at http://localhost:3000");
  console.log("Press Ctrl+C to stop.");
});
