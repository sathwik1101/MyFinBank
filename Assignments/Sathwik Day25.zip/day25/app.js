const express = require("express");
const app = express();

app.use(express.json());

let courses = [
  { id: 1, name: "React Mastery", duration: "6 weeks" },
  { id: 2, name: "Node.js Fundamentals", duration: "4 weeks" }
];
let nextId = 3;

let users = [
  { id: 1, name: "John Doe", email: "john@example.com" }
];
let nextUserId = 2;

app.get("/status", (req, res) => {
  res.send("App is live");
});

app.get("/api/courses", (req, res) => {
  res.json(courses);
});

app.post("/api/courses", (req, res) => {
  if (!req.body.name || !req.body.duration) {
    return res.status(400).json({ error: "Course name and duration are required" });
  }
  const course = { id: nextId++, name: req.body.name, duration: req.body.duration };
  courses.push(course);
  res.status(201).json(course);
});

app.get("/api/users", (req, res) => {
  res.json(users);
});

app.post("/api/users", (req, res) => {
  if (!req.body.name || !req.body.email) {
    return res.status(400).json({ error: "Name and email are required" });
  }
  const user = { id: nextUserId++, name: req.body.name, email: req.body.email };
  users.push(user);
  res.status(201).json(user);
});

module.exports = app;
