const chai = require("chai");
const request = require("supertest");
const app = require("../app");

const expect = chai.expect;

describe("Courses API", () => {
  it("GET /api/courses should return all courses", async () => {
    const res = await request(app).get("/api/courses");
    expect(res.status).to.equal(200);
    expect(res.body).to.be.an("array");
  });

  it("POST /api/courses should create a new course", async () => {
    const res = await request(app).post("/api/courses").send({ name: "AWS Basics", duration: "5 weeks" });
    expect(res.status).to.equal(201);
    expect(res.body).to.have.property("name", "AWS Basics");
  });

  it("POST /api/courses should return error if name is missing", async () => {
    const res = await request(app).post("/api/courses").send({ duration: "5 weeks" });
    expect(res.status).to.equal(400);
    expect(res.body).to.have.property("error");
  });
});

describe("Users API", () => {
  it("GET /api/users should return all users", async () => {
    const res = await request(app).get("/api/users");
    expect(res.status).to.equal(200);
    expect(res.body).to.be.an("array");
  });

  it("POST /api/users should create a new user", async () => {
    const res = await request(app).post("/api/users").send({ name: "Jane", email: "jane@example.com" });
    expect(res.status).to.equal(201);
    expect(res.body).to.have.property("email", "jane@example.com");
  });

  it("POST /api/users should return error if email is missing", async () => {
    const res = await request(app).post("/api/users").send({ name: "Jane" });
    expect(res.status).to.equal(400);
    expect(res.body).to.have.property("error");
  });
});

describe("Status", () => {
  it("GET /status should return App is live", async () => {
    const res = await request(app).get("/status");
    expect(res.status).to.equal(200);
    expect(res.text).to.equal("App is live");
  });
});
